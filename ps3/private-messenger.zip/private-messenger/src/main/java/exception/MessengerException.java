package exception;

public class MessengerException extends Exception {
    public MessengerException() {
        super();
    }

    public MessengerException(String message) {
        super(message);
    }
}
