import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        ProgramController controller = new ProgramController();
        controller.run();
    }
}
