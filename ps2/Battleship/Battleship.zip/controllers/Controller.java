package controllers;

public interface Controller {
    void run();
}
