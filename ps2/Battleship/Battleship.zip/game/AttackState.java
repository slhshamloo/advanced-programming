package game;

public enum AttackState {
    MISS, DESTROY, ELIMINATE, EXPLODE
}
